from collections import Counter
import random

def player(prev_play, opponent_history=[], player_history=[], play_order=[{
              "RR": 0,
              "RP": 0,
              "RS": 0,
              "PR": 0,
              "PP": 0,
              "PS": 0,
              "SR": 0,
              "SP": 0,
              "SS": 0,
          }], most_freq_moves=[]):
  

    # print(len(player_history))
    if (len(player_history) == 1000):
      # Reset
      opponent_history.clear()
      player_history.clear()

      play_order.pop()
      play_order.append({"RR": 0,"RP": 0,"RS": 0,"PR": 0,"PP": 0,"PS": 0,"SR": 0,"SP": 0,"SS": 0})

    last_two = "".join(player_history[-2:])
    if len(last_two) == 2:
        play_order[0][last_two] += 1

    opponent_history.append(prev_play)
    choices = ["R", "P", "S"]
    # print(len(player_history))

    # Strictest Checks come first.
    if len(player_history) > 10:
      most_freq_moves.append(Counter(player_history[-10:]).most_common(1)[0][0])


    counters = {"R": "P", "P": "S", "S": "R"}
    


    # Mrugesh - Plays against your most frequent move from the last 10 iterations
    if len(player_history) > 20:
      # print("Mrugesh")
      # If last 5 opponent moves were to counter your frequent move set flag
      flag = True
      x = 3

      for i in range(-1, -x, -1):
        if opponent_history[i] != counters[most_freq_moves[i]]:
          flag = False
          break

      # Counter the Counter
      if flag:
        # print("mruge")
        move = counters[counters[most_freq_moves[-1]]]
        player_history.append(move)
        return move

    # Quincy's Pattern
    quincy_pattern = ["RRPPS", "RPPSR", "PPSRR", "PSRRP", "SRRPP"]


    if "".join(opponent_history[-5:]) in quincy_pattern:
      # print("quincy")
      move = counters[opponent_history[-5]]
      player_history.append(move)
      return move

    # Kris - Counters your last move
    expected_countered_moves = 4

    if len(opponent_history) > expected_countered_moves:
      # Opponent history counters should be 1 off to the right from player history moves
      flag = True
      oh_check = opponent_history[-expected_countered_moves:]
      ph_check = player_history[-expected_countered_moves - 1:]
      # print(oh_check, ph_check)
      ph_check.pop()
      for i in range(-1, -expected_countered_moves, -1):
        if counters[ph_check[i]] != oh_check[i]:
          flag = False
          break

      if flag:
        # print("kris")
        # Counter to Counter to your last move
        move = counters[counters[player_history[-1]]]
        player_history.append(move)
        return move

    # print("mybot", play_order)
    if len(player_history) < 2:
      # print("random", end=" ")
      move = random.choice(choices)
      player_history.append(move)
      return move

    if random.random() < 0.20:
      # print("random")
      move = random.choice(choices)
      player_history.append(move)
      return move



    ############################################################################

    prev_opponent_play = player_history[-1] if len(player_history) > 0 else None
    if not prev_opponent_play:
        prev_opponent_play = 'R'





    potential_plays = [
        prev_opponent_play + "R",
        prev_opponent_play + "P",
        prev_opponent_play + "S",
    ]

    sub_order = {
        k: play_order[0][k]
        for k in potential_plays if k in play_order[0]
    }

    prediction = max(sub_order, key=sub_order.get)[-1:]

    move = counters[counters[prediction]]
    player_history.append(move)
    # print("abbey")
    return move

    ############################################################################

    

    # print("random", end=" ")
    move = random.choice(choices)
    player_history.append(move)

    return move

